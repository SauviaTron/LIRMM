This version of the LoRaSensorTile sketch sends BME280 data (pressure, temperature, humidity) as well as battery voltage to the Things Network via LoRaWAN just to demonstrate the process, etc. The data looked like this:

![data](https://user-images.githubusercontent.com/6698410/35026323-42420b1e-faff-11e7-9c01-a1dca39500c2.jpg)
