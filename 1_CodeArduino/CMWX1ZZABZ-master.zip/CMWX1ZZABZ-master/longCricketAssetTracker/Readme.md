Long Cricket Asset Tracker

Arduino sketch to manage the long Cricket Asset Tracker available on [Tindie](https://www.tindie.com/products/TleraCorp/long-cricket-loralorawangnss-asset-tracker/).

![longCricket](https://user-images.githubusercontent.com/6698410/50252240-337aa280-039b-11e9-89bd-95fb6a15dbd0.jpg)
