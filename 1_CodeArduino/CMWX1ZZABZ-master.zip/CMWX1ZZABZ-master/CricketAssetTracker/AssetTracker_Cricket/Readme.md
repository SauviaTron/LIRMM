Latest version of the Cricket Asset Tracker library. Typical current usage at 1 minute sensor logging, ten minute LoRaWAN Tx, and 2 hour GNSS fix intervals is 300 - 400 uA depending on outdoor position and frequency of wake-on-motion fix intervals. Output data to CayenneLPP dashboard.

![CayenneLPP](https://user-images.githubusercontent.com/6698410/42728893-1e30cec8-877b-11e8-87dc-08c81cae580e.jpg)
