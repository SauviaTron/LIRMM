Cricket is a 23 mm x 46 mm CMWX1ZZABZ-hosted asset tracker using the concurrent GNSS engine CAM M8Q and includes STBC08 battery charger, 8 MByte SPI NOR Flash for data logging, BMA280 accelerometer for motion detection and BME280 for environmental sensing. See [here](https://hackaday.io/project/35169-hackable-cmwx1zzabz-lora-devices) for more discussion.

![Cricket](https://user-images.githubusercontent.com/6698410/34909788-8f515fe0-f85c-11e7-8de5-30879457ddd1.jpg)

Cricket is for sale at [Tindie](https://www.tindie.com/products/TleraCorp/cricket-lorawangnss-asset-tracker/).
